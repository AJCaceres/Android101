package com.example.homework5functions

open class Clothing(var name: String,  var size: Int) {

    var isClean: Boolean = true

    constructor(name: String, size: Int, isClean: Boolean): this(name, size){
        this.isClean = isClean
    }

    open fun washClothing(){
        isClean = true
    }
}