package com.example.homework5functions

class ShoesWithLaces(name: String, size: Int): Clothing(name, size) {

    var lacesName: String? = null
    var areLacesClean: Boolean = false
    var areShoeLaced: Boolean = false

    fun laceShoes(name: String){
        this.lacesName = name
        this.areLacesClean = true
        areShoeLaced = true
    }

    override fun washClothing() {
        super.washClothing()
        areLacesClean = true
    }

}