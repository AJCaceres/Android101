package com.example.homework5functions

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import java.time.Year


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val t_shirt: Clothing = Clothing(name = "t-shirt", size = 14)
        val isClean = t_shirt.isClean
        t_shirt.washClothing()

        val sneakers: ShoesWithLaces = ShoesWithLaces("sneakers", 8)
        sneakers.laceShoes("Laceys")
        sneakers.washClothing()

        //Log.d("Test", "Information of shoes " + sneakers.lacesName)
    }

    }