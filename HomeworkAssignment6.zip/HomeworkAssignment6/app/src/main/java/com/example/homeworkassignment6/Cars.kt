package com.example.homeworkassignment6

class Cars(make: String, model: String, year: Int, weight: Float): Vehicle(make, model, year, weight) {

    var isDriving: Boolean = true
    var warning: String= ""

    fun drive(){
        if (needsMaintenance) {
            isDriving = false
            warning = "Needs maintenance, trips extra "+ (tripsSinceMaintenance - 99)
        } else {
            isDriving = true
        }

    }

    fun stop() {
        isDriving = false
        tripsSinceMaintenance += 1

        if (tripsSinceMaintenance > 100) {
            needsMaintenance = true
        }
    }
}