package com.example.homeworkassignment6

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val car1: Cars = Cars("Mazda", "3", 2019, 1800.20F)
        for (i in 1..25) {
            car1.drive()
            car1.stop()
        }

        val car2: Cars = Cars("Mazda", "CX5", 2021, 2000.20F)
        for (i in 1..102) {
            car2.drive()
            car2.stop()
        }

        val car3: Cars = Cars("Mazda", "RX7", 2001, 16800.20F)
        for (i in 1..50) {
            car3.drive()
            car3.stop()
        }

        Log.d("info car 1",car1.make+" "+car1.model+" "+car1.year+" "+car1.weight+" "+car1.needsMaintenance+" "+car1.tripsSinceMaintenance+" "+car1.warning)
        Log.d("info car 2",car2.make+" "+car2.model+" "+car2.year+" "+car2.weight+" "+car2.needsMaintenance+" "+car2.tripsSinceMaintenance+" "+car2.warning)
        Log.d("info car 3",car3.make+" "+car3.model+" "+car3.year+" "+car3.weight+" "+car3.needsMaintenance+" "+car3.tripsSinceMaintenance+" "+car3.warning)
    }
}