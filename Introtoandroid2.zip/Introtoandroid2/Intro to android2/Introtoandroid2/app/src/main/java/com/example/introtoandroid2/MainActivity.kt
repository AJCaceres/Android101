package com.example.introtoandroid2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.core.graphics.convertTo
import java.time.Year
import java.util.logging.LoggingMXBean
import kotlin.math.log

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        /*
Homework
Variables

This lesson is to know how to use variables.
I need to list the characteristics of my favorite song.
*/


        val Name: String = "Legends"
        val Artist: String = "Juice WRLD"
        val Album: String = "Legends"
        val Genre: String = "Hip-hop/ Rap"
        val DurationInSeconds: Int  = 192
        val YearOfPublish: Int = 2018
        val SimilarArtists: String  = "Pop Smoke and Lil Peep"
        val Mood: String  = "Emotional"
        val Producer: String  = "Russ Chell and Take a Daytrip"

        Log.d("Name",Name)
        Log.d("Artist",Artist)
        Log.d("Album",Album)
        Log.d("Genre",Genre)
        Log.d("Duration",DurationInSeconds.toString())
        Log.d("Publish",YearOfPublish.toString())
        Log.d("Similar artists",SimilarArtists)
        Log.d("Mood",Mood)
        Log.d("Producer",Producer)

    }
}