package com.example.introtoandroid2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.core.graphics.convertTo
import java.time.Year
import java.util.logging.LoggingMXBean
import kotlin.math.log

class MainActivity : AppCompatActivity() {

    var playerPosition: Int = 0
    val minPosition: Int = 0
    val maxPosition: Int = 10

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //Functions intro
        //move()
        val isValidMove = move(-5)

    }
    fun move(){
        playerPosition += 2
    }

    // Functions with parameters
    fun move(byAmount: Int): Boolean {
        if (playerPosition + byAmount > maxPosition || playerPosition + byAmount < minPosition){
            return false
        } else {
            playerPosition += byAmount
            return true
        }
    }
}